// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>


int main()
{
	std::cout << "Buffer Overflow Example - Daulton Truett \n" << std::endl;

	// TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
	//  even though it is a constant and the compiler buffer overflow checks are on.
	//  You need to modify this method to prevent buffer overflow without changing the account_number
	//  variable and its position in the declaration. It must always be directly before the variable used for input.

	const std::string account_number = "CharlieBrown42";

	//	NOTE: This method can be used in lie of utilizing a different variable type
	//	HOWEVER! This method doesn't allow us to detect if an overflow was attempted as it will automatically trucate the input to the allowed size.
	// set the width of allowed input that will be stored in the buffer
	// std::cin.getline(user_input, sizeof(user_input)) will cut off all input that exceeds the fixed buffer size set by "user_input",
	// preventing buffer overflow - DT

	//	METHOD 1 - DT

	//char user_input[20];
	//std::cin.getline(user_input, sizeof(user_input)); <- method without notification of overflow attempt, prevents without notifying - DT
	//	OR
	//std::cin >> setw(sizeof(user_input)) >> user_input;

	//	METHOD 2 - DT
	
	// This method puts input into a string variable and ensures that if a user inputs a value > 20 that overflow will not occur by entering a while loop
	// that forces the user to enter a string of 20 characters or less to proceed.
	// Using a string in liu of a fixed array ensures the user cannot exceed a pre-defined buffer size and allows us to check the size of the variable
	// without causing overflow to detect when a user attempts to exceed the allowed size - DT
	std::string user_str_input;

	std::cout << "Enter a value: ";
	std::cin >> user_str_input;

	while (user_str_input.length() > 20) {
		std::cout << "ERROR: OVERFLOW ATTEMPTED! \n";
		std::cout << "Enter a value 20 characters or less: ";
		std::cin >> user_str_input;
	};

	std::cout << "You entered: " << user_str_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
};

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
